# [util-chewup](https://github.com/samwhelp/util-chewup)

Chewing user phrase editor and cli util.

## Prototype

* [demo-libchewing](https://github.com/samwhelp/demo-libchewing)
