#!/usr/bin/env python3

from chewup.app import App

def main ():
	app = App()
	app.init()
	app.run()

if __name__ == '__main__':
	main()
